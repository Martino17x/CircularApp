import { Theme, Components } from '@mui/material/styles';

/* eslint-disable import/prefer-default-export */
export const buttonCustomizations: Components<Theme> = {};
